scriptevent aiplayer:cmd Stop.
