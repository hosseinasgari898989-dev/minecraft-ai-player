scriptevent aiplayer:status
