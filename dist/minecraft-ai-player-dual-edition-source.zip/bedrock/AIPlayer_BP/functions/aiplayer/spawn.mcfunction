scriptevent aiplayer:spawn
